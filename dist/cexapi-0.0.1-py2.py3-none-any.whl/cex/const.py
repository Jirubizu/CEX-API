
S = {
    'b'     :   'boxes?q=',
    'bsCI'  :   'boxes?superCatId=',
    'c'     :   '&count=',
    'sO'    :   '&sortOrder=',
    'q'     :   '&q='
}

D = {
    'bI'    :   'boxId',
    'bN'    :   'boxName',
    'iMB'   :   'isMasterBox',
    'cI'    :   'categoryId',
    'cN'    :   'categoryName',
    'cFN'   :   'categoryFriendlyName',
    'sCI'   :   'superCatId',
    'sCN'   :   'superCatName',
    'sCFN'  :   'superCatFriendlyName',
    'cB'    :   'cannotBuy',
    'iNB'   :   'isNewBox',
    'sP'    :   'sellPrice',
    'cP'    :   'cashPrice',
    'eP'    :   'exchangePrice',
    'bR'    :   'boxRating',
    'oOS'   :   'outOfStock',
    'oOES'  :   'outOfEcomStock'
}